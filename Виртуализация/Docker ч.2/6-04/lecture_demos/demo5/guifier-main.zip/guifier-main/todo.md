# URGENT

- www.guifier.com is not indexed. please make sure people can access guifier through that url

- add an empty content when having an array or an object container thats empty

- keep the levels lines in the array container like they exist in the code editor
- fix the styles inconsistancies in the different data shapes in the guifier
- make the remove button and other buttons can be add in the same place to show in a smooth animation way

- show an error in the guifier if the parsing process didnt go well
- add the fullscreen button at the main container header

- render the md from the server side
- add in story book empty containers for array and object and in a nested ways too
- and add a book with a container with three elements only
- make the add and delete button have muted color nad gets primary on hover
- add the ability to add information for each field. for exmaple if you have a `name` property in the json. you can add an info that says `the name of the main charachter in the game`

# todo

- add redirect rules from `www.guifier.com` to `guifier.com` using the solution in this issue `https://github.com/Dokploy/dokploy/issues/3088#issuecomment-4017526235`
- add the feature of saving a code editor data in the url. so that a person can share it and send it anywhere
- xml page should should work without the need of a <root> element. adding xml properties witout a parent root element should work
- create a kanban in github
- check every page of the website and add content to them. Headers are not enough you need to add paragraphs. you can use seo tools to check every page of the website. this is so that you can be approved in google adsense
- change the name of the `guifier` class into `guifierClass`
- work on compiling the Guifier Class successfully and work on the npm CICD to publish the package there
- announce GuifierV2 in the ReadMe file
- move the lib/guifier up to the `src` directory
- start sharing this library in all public repos "discussians" page where its related
- add the feature of different background colors for input in different levels and its container to make them more visible
- add a button to fields to nullify the values of those fields
- add fade animation to color transition in the guifier website when navigating to `json` `yaml` etc...

# SEO

- you can answear people on stackoverflow or other forumes who have json viewier related stuff questions
- create blogs on dev.to introducing guifier and how to use it
